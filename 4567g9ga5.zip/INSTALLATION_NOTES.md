# CampusCare Complaint System — Installation Record

## 1. Environment
- Platform: Nimbus workspace
- PHP version: 8.4.26
- PHP API: 20240924
- Architecture: ARM64
- Project folder: /home/workspace/my-project/complaint-system

## 2. PHP MySQL Extensions
Required extensions:
- PDO
- pdo_mysql
- mysqli
- mysqlnd

## 3. Downloaded MySQL Extension Package
Package:
php8.4-mysql_8.4.26-1~deb13u1_arm64.deb

Download URL:
https://security.debian.org/debian-security/pool/updates/main/p/php8.4/php8.4-mysql_8.4.26-1~deb13u1_arm64.deb

Extracted extension files:
- mysqlnd.so
- pdo_mysql.so
- mysqli.so

Expected extraction folder:
/home/workspace/my-project/php-mysql-local/extracted/usr/lib/php/20240924/

## 4. PHP Local Configuration
Configuration file:
/home/workspace/my-project/php-mysql-local/php-local.ini

Expected contents:
extension=/home/workspace/my-project/php-mysql-local/extracted/usr/lib/php/20240924/mysqlnd.so
extension=pdo
extension=/home/workspace/my-project/php-mysql-local/extracted/usr/lib/php/20240924/pdo_mysql.so
extension=/home/workspace/my-project/php-mysql-local/extracted/usr/lib/php/20240924/mysqli.so

Note:
PDO may show "already loaded" because it is enabled by default.
Check that pdo_mysql appears in the loaded modules.

## 5. Verify PHP Extensions
Run:
php -c /home/workspace/my-project/php-mysql-local/php-local.ini -m

Check PDO MySQL drivers:
php -c /home/workspace/my-project/php-mysql-local/php-local.ini -r 'var_export(PDO::getAvailableDrivers());'

Expected driver list should include:
mysql

## 6. Start CampusCare Server
Run:
cd /home/workspace/my-project/complaint-system
php -c /home/workspace/my-project/php-mysql-local/php-local.ini -S 0.0.0.0:8080

Keep the terminal open while using the website.

## 7. Restore Notes
- Keep PHP extension files outside the complaint-system folder.
- If Nimbus resets, check whether the extracted extension files and php-local.ini still exist.
- Re-download and extract the package if those files are missing.
- Do not assume database credentials remain unchanged after a workspace reset.
- Keep database passwords out of this file.
- Do not delete or recreate existing database tables without backing up data first.
