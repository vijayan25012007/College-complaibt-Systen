<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (($_SESSION['user_role'] ?? 'student') === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: complaint.php');
    exit;
}

require_once __DIR__ . '/config/database.php';

$errors = [];

$title = trim($_POST['title'] ?? '');
$category = trim($_POST['category'] ?? '');
$priority = trim($_POST['priority'] ?? 'Medium');
$location = trim($_POST['location'] ?? '');
$description = trim($_POST['description'] ?? '');
$csrfToken = $_POST['csrf_token'] ?? '';

$allowedCategories = [
    'Classroom',
    'Laboratory',
    'Hostel',
    'Library',
    'Canteen',
    'Cleanliness',
    'Electricity',
    'Water Supply',
    'Internet',
    'Transport',
    'Harassment or Safety',
    'Other',
];

$allowedPriorities = ['Low', 'Medium', 'High', 'Urgent'];

if (
    !isset($_SESSION['csrf_token']) ||
    !is_string($csrfToken) ||
    !hash_equals($_SESSION['csrf_token'], $csrfToken)
) {
    $errors[] = 'Your form session expired. Please try again.';
}

if (mb_strlen($title) < 5 || mb_strlen($title) > 150) {
    $errors[] = 'The complaint title must be between 5 and 150 characters.';
}

if (!in_array($category, $allowedCategories, true)) {
    $errors[] = 'Please select a valid complaint category.';
}

if (!in_array($priority, $allowedPriorities, true)) {
    $errors[] = 'Please select a valid priority.';
}

if (mb_strlen($location) > 150) {
    $errors[] = 'The location must not exceed 150 characters.';
}

if (mb_strlen($description) < 20 || mb_strlen($description) > 5000) {
    $errors[] = 'The description must be between 20 and 5000 characters.';
}

if ($errors) {
    $_SESSION['complaint_form_errors'] = $errors;
    $_SESSION['complaint_form_old'] = [
        'title' => $title,
        'category' => $category,
        'priority' => $priority,
        'location' => $location,
        'description' => $description,
    ];

    header('Location: complaint.php');
    exit;
}

try {
    $stmt = $pdo->prepare(
        'INSERT INTO complaints
            (user_id, title, category, priority, location, description, status, created_at)
         VALUES
            (:user_id, :title, :category, :priority, :location, :description, :status, NOW())'
    );

    $stmt->execute([
        'user_id' => (int) $_SESSION['user_id'],
        'title' => $title,
        'category' => $category,
        'priority' => $priority,
        'location' => $location !== '' ? $location : null,
        'description' => $description,
        'status' => 'Pending',
    ]);

    unset($_SESSION['csrf_token']);

    $_SESSION['complaint_success'] =
        'Your complaint has been submitted successfully.';

    header('Location: dashboard.php');
    exit;
} catch (PDOException $e) {
    error_log('CampusCare complaint submission error: ' . $e->getMessage());

    $_SESSION['complaint_form_errors'] = [
        'We could not submit your complaint right now. Please try again later.',
    ];

    $_SESSION['complaint_form_old'] = [
        'title' => $title,
        'category' => $category,
        'priority' => $priority,
        'location' => $location,
        'description' => $description,
    ];

    header('Location: complaint.php');
    exit;
}
