<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CampusCare Database Configuration
|--------------------------------------------------------------------------
| Connects the PHP workspace to the separate Nimbus MySQL workspace.
*/

$host = 'db01.dbhost.dev';
$port = 5051;
$dbname = 'db_4567hjv9c';
$username = 'user_4567hjv9c';
$password = 'p4567hjv9c';

$dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    // Log the technical error privately; do not expose credentials to visitors.
    error_log('CampusCare database connection failed: ' . $e->getMessage());

    http_response_code(500);
    exit('A database connection error occurred. Please try again later.');
}

