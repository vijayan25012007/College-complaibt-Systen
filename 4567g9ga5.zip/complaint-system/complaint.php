<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (($_SESSION['user_role'] ?? 'student') === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

$old = $_SESSION['complaint_form_old'] ?? [];
$errors = $_SESSION['complaint_form_errors'] ?? [];

unset($_SESSION['complaint_form_old'], $_SESSION['complaint_form_errors']);

function complaintFormEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$categories = [
    'Classroom',
    'Laboratory',
    'Hostel',
    'Library',
    'Canteen',
    'Cleanliness',
    'Electricity',
    'Water Supply',
    'Internet',
    'Transport',
    'Harassment or Safety',
    'Other',
];

$priorities = ['Low', 'Medium', 'High', 'Urgent'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit a Complaint | CampusCare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="app-page">

<header class="navbar app-navbar">
    <a href="dashboard.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="complaint.php" class="active">New Complaint</a>
        <a href="logout.php" class="nav-login">Logout</a>
    </nav>
</header>

<main class="dashboard-container">
    <div class="page-heading">
        <a href="dashboard.php" class="back-link">&larr; Back to Dashboard</a>
        <span class="eyebrow">CAMPUSCARE SUPPORT</span>
        <h1>Submit a Complaint</h1>
        <p>Tell us about the issue. Provide enough detail to help the administration review it.</p>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
            <strong>Please correct the following:</strong>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= complaintFormEscape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <section class="form-panel">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">COMPLAINT DETAILS</span>
                <h2>Describe your concern</h2>
            </div>
            <span class="required-note">* Required fields</span>
        </div>

        <form action="submit_complaint.php" method="POST" class="portal-form" data-validate>
            <input type="hidden" name="csrf_token"
                   value="<?= complaintFormEscape($_SESSION['csrf_token'] ??= bin2hex(random_bytes(32))) ?>">

            <div class="form-group">
                <label for="title">Complaint Title <span>*</span></label>
                <input
                    type="text"
                    id="title"
                    name="title"
                    placeholder="Briefly describe the issue"
                    maxlength="150"
                    minlength="5"
                    value="<?= complaintFormEscape($old['title'] ?? '') ?>"
                    required
                >
                <small>Use a clear title that summarizes your concern.</small>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label for="category">Category <span>*</span></label>
                    <select id="category" name="category" required>
                        <option value="">Choose a category</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= complaintFormEscape($category) ?>"
                                <?= ($old['category'] ?? '') === $category ? 'selected' : '' ?>>
                                <?= complaintFormEscape($category) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="priority">Priority <span>*</span></label>
                    <select id="priority" name="priority" required>
                        <?php foreach ($priorities as $priority): ?>
                            <option value="<?= complaintFormEscape($priority) ?>"
                                <?= ($old['priority'] ?? 'Medium') === $priority ? 'selected' : '' ?>>
                                <?= complaintFormEscape($priority) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small>Choose the urgency appropriate to the issue.</small>
                </div>
            </div>

            <div class="form-group">
                <label for="location">Location on Campus</label>
                <input
                    type="text"
                    id="location"
                    name="location"
                    placeholder="e.g. Block B, Room 204"
                    maxlength="150"
                    value="<?= complaintFormEscape($old['location'] ?? '') ?>"
                >
            </div>

            <div class="form-group">
                <label for="description">Complaint Description <span>*</span></label>
                <textarea
                    id="description"
                    name="description"
                    rows="7"
                    minlength="20"
                    maxlength="5000"
                    placeholder="Explain what happened, where it happened, and any relevant details..."
                    required
                ><?= complaintFormEscape($old['description'] ?? '') ?></textarea>
                <small>Enter at least 20 characters. Do not include passwords or other sensitive information.</small>
            </div>

            <div class="form-actions">
                <a href="dashboard.php" class="btn btn-outline">Cancel</a>
                <button type="submit" class="btn">
                    Submit Complaint <span aria-hidden="true">&rarr;</span>
                </button>
            </div>
        </form>
    </section>
</main>

<footer class="footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare</p>
</footer>

<script src="js/validation.js"></script>
</body>
</html>
