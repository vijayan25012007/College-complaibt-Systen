<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$allowedStatuses = [
    'Pending',
    'In Progress',
    'Resolved',
    'Rejected',
];

$errors = [];
$complaints = [];

if ($statusFilter !== '' && !in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

try {
    $sql = '
        SELECT
            c.id,
            c.title,
            c.category,
            c.priority,
            c.location,
            c.description,
            c.status,
            c.created_at,
            u.name AS student_name,
            u.email AS student_email
        FROM complaints c
        INNER JOIN users u ON u.id = c.user_id
        WHERE 1 = 1
    ';

    $params = [];

    if ($search !== '') {
        $sql .= '
            AND (
                c.title LIKE :title
                OR c.description LIKE :description
                OR u.name LIKE :student_name
                OR u.email LIKE :student_email
            )
        ';

        $keyword = '%' . $search . '%';

        $params['title'] = $keyword;
        $params['description'] = $keyword;
        $params['student_name'] = $keyword;
        $params['student_email'] = $keyword;
    }

    if ($statusFilter !== '') {
        $sql .= ' AND c.status = :status';
        $params['status'] = $statusFilter;
    }

    $sql .= ' ORDER BY c.created_at DESC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $complaints = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('CampusCare complaint listing error: ' . $e->getMessage());
    $errors[] = 'Complaints could not be loaded. Please try again later.';
}

function adminComplaintsEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function adminComplaintsStatusClass(string $status): string
{
    return match ($status) {
        'Resolved' => 'status-resolved',
        'In Progress' => 'status-progress',
        'Rejected' => 'status-rejected',
        default => 'status-pending',
    };
}

function adminComplaintsPriorityClass(string $priority): string
{
    return match ($priority) {
        'Urgent' => 'priority-urgent',
        'High' => 'priority-high',
        'Low' => 'priority-low',
        default => 'priority-medium',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Complaints | CampusCare</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="app-page">

<header class="navbar app-navbar">
    <a href="dashboard.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="dashboard.php">Overview</a>
        <a href="complaints.php" class="active">Manage Complaints</a>
        <a href="../logout.php" class="nav-login">Logout</a>
    </nav>
</header>

<main class="dashboard-container">
    <section class="welcome-banner">
        <div>
            <span class="eyebrow">ADMINISTRATION PANEL</span>
            <h1>Manage Complaints</h1>
            <p>Search reports, review student concerns, and update their status.</p>
        </div>

        <a href="dashboard.php" class="btn btn-outline">
            &larr; Dashboard
        </a>
    </section>

    <?php if (isset($_SESSION['admin_message'])): ?>
        <div class="alert alert-success" role="status">
            <?= adminComplaintsEscape($_SESSION['admin_message']) ?>
        </div>
        <?php unset($_SESSION['admin_message']); ?>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
            <?php foreach ($errors as $error): ?>
                <p><?= adminComplaintsEscape($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <section class="content-panel">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">COMPLAINT REGISTER</span>
                <h2>All Submissions</h2>
                <p><?= count($complaints) ?> complaint(s) found</p>
            </div>
        </div>

        <form method="GET" action="complaints.php" class="filter-form">
            <div class="form-group filter-search">
                <label for="search">Search complaints</label>
                <input
                    type="search"
                    id="search"
                    name="search"
                    value="<?= adminComplaintsEscape($search) ?>"
                    placeholder="Search title, description, or student..."
                    maxlength="150"
                >
            </div>

            <div class="form-group filter-status">
                <label for="status">Filter by status</label>
                <select id="status" name="status">
                    <option value="">All statuses</option>
                    <?php foreach ($allowedStatuses as $status): ?>
                        <option value="<?= adminComplaintsEscape($status) ?>"
                            <?= $statusFilter === $status ? 'selected' : '' ?>>
                            <?= adminComplaintsEscape($status) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="filter-actions">
                <button type="submit" class="btn">Apply Filters</button>
                <a href="complaints.php" class="btn btn-outline">Clear</a>
            </div>
        </form>

        <?php if (!$complaints && !$errors): ?>
            <div class="empty-state">
                <div class="empty-icon">&#9776;</div>
                <h3>No matching complaints</h3>
                <p>Try changing your search terms or status filter.</p>
            </div>
        <?php elseif ($complaints): ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                    <tr>
                        <th>Complaint</th>
                        <th>Student</th>
                        <th>Priority</th>
                        <th>Date Submitted</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($complaints as $complaint): ?>
                        <tr>
                            <td>
                                <strong><?= adminComplaintsEscape($complaint['title']) ?></strong>
                                <span class="table-subtext">
                                    #<?= (int) $complaint['id'] ?> ·
                                    <?= adminComplaintsEscape($complaint['category']) ?>
                                </span>
                            </td>
                            <td>
                                <?= adminComplaintsEscape($complaint['student_name']) ?>
                                <span class="table-subtext">
                                    <?= adminComplaintsEscape($complaint['student_email']) ?>
                                </span>
                            </td>
                            <td>
                                <span class="priority-badge <?= adminComplaintsPriorityClass($complaint['priority']) ?>">
                                    <?= adminComplaintsEscape($complaint['priority']) ?>
                                </span>
                            </td>
                            <td>
                                <?= adminComplaintsEscape(
                                    date('d M Y', strtotime($complaint['created_at']))
                                ) ?>
                            </td>
                            <td>
                                <span class="status-badge <?= adminComplaintsStatusClass($complaint['status']) ?>">
                                    <?= adminComplaintsEscape($complaint['status']) ?>
                                </span>
                            </td>
                            <td>
                                <form method="GET" action="update_status.php">
                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= (int) $complaint['id'] ?>"
                                    >
                                    <button type="submit" class="btn btn-small">
                                        Review
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>

<footer class="footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare Administration</p>
</footer>

<script src="../js/validation.js"></script>
</body>
</html>