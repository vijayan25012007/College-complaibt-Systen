<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

$stats = [
    'total' => 0,
    'pending' => 0,
    'in_progress' => 0,
    'resolved' => 0,
    'rejected' => 0,
];

$recentComplaints = [];
$loadError = false;

try {
    $stmt = $pdo->query(
        "SELECT
            COUNT(*) AS total,
            COALESCE(SUM(status = 'Pending'), 0) AS pending,
            COALESCE(SUM(status = 'In Progress'), 0) AS in_progress,
            COALESCE(SUM(status = 'Resolved'), 0) AS resolved,
            COALESCE(SUM(status = 'Rejected'), 0) AS rejected
         FROM complaints"
    );

    $stats = $stmt->fetch() ?: $stats;

    $stmt = $pdo->query(
        'SELECT c.id, c.title, c.category, c.priority, c.status,
                c.created_at, u.name AS student_name
         FROM complaints c
         INNER JOIN users u ON u.id = c.user_id
         ORDER BY c.created_at DESC
         LIMIT 8'
    );

    $recentComplaints = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('CampusCare admin dashboard error: ' . $e->getMessage());
    $loadError = true;
}

function adminDashboardEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function adminDashboardStatusClass(string $status): string
{
    return match ($status) {
        'Resolved' => 'status-resolved',
        'In Progress' => 'status-progress',
        'Rejected' => 'status-rejected',
        default => 'status-pending',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | CampusCare</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="app-page">

<header class="navbar app-navbar">
    <a href="dashboard.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="dashboard.php" class="active">Overview</a>
        <a href="complaints.php">Manage Complaints</a>
        <a href="../logout.php" class="nav-login">Logout</a>
    </nav>
</header>

<main class="dashboard-container">
    <section class="welcome-banner">
        <div>
            <span class="eyebrow">ADMINISTRATION PANEL</span>
            <h1>Welcome, <?= adminDashboardEscape($_SESSION['user_name'] ?? 'Administrator') ?>.</h1>
            <p>Monitor campus concerns and manage submitted complaints.</p>
        </div>

        <a href="complaints.php" class="btn">
            Manage Complaints <span aria-hidden="true">&rarr;</span>
        </a>
    </section>

    <?php if ($loadError): ?>
        <div class="alert alert-error" role="alert">
            Complaint statistics could not be loaded. Please try again later.
        </div>
    <?php endif; ?>

    <section class="stats-grid" aria-label="Complaint statistics">
        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">All Complaints</span>
                <span class="stat-icon purple">&#9776;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['total'] ?></p>
            <span class="stat-caption">Total submissions</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">Pending</span>
                <span class="stat-icon orange">&#9711;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['pending'] ?></p>
            <span class="stat-caption">Awaiting review</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">In Progress</span>
                <span class="stat-icon teal">&#8635;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['in_progress'] ?></p>
            <span class="stat-caption">Being addressed</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">Resolved</span>
                <span class="stat-icon green">&#10003;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['resolved'] ?></p>
            <span class="stat-caption">Completed complaints</span>
        </article>
    </section>

    <section class="content-panel">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">LATEST ACTIVITY</span>
                <h2>Recent Complaints</h2>
            </div>
            <a href="complaints.php" class="text-link">View all &rarr;</a>
        </div>

        <?php if (!$recentComplaints): ?>
            <div class="empty-state">
                <div class="empty-icon">&#9776;</div>
                <h3>No complaints found</h3>
                <p>Submitted complaints will appear here for administrative review.</p>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                    <tr>
                        <th>Complaint</th>
                        <th>Student</th>
                        <th>Priority</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentComplaints as $complaint): ?>
                        <tr>
                            <td>
                                <strong><?= adminDashboardEscape($complaint['title']) ?></strong>
                                <span class="table-subtext">
                                    #<?= (int) $complaint['id'] ?> ·
                                    <?= adminDashboardEscape($complaint['category']) ?>
                                </span>
                            </td>
                            <td><?= adminDashboardEscape($complaint['student_name']) ?></td>
                            <td><?= adminDashboardEscape($complaint['priority']) ?></td>
                            <td>
                                <?= adminDashboardEscape(
                                    date('d M Y', strtotime($complaint['created_at']))
                                ) ?>
                            </td>
                            <td>
                                <span class="status-badge <?= adminDashboardStatusClass($complaint['status']) ?>">
                                    <?= adminDashboardEscape($complaint['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="help-panel">
        <div>
            <h3>Complaint management</h3>
            <p>Review reports, update their status, and record administrative responses.</p>
        </div>
        <a href="complaints.php" class="btn btn-outline">Open Management &rarr;</a>
    </section>
</main>

<footer class="footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare Administration</p>
</footer>

<script src="../js/validation.js"></script>
</body>
</html>
