<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

$allowedStatuses = [
    'Pending',
    'In Progress',
    'Resolved',
    'Rejected',
];

$complaintId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$complaintId || $complaintId < 1) {
    $_SESSION['admin_message'] = 'Please select a valid complaint.';
    header('Location: complaints.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $status = trim($_POST['status'] ?? '');
    $response = trim($_POST['admin_response'] ?? '');
    $csrfToken = $_POST['csrf_token'] ?? '';

    if ($postedId !== $complaintId) {
        $errors[] = 'Invalid complaint reference.';
    }

    if (
        !isset($_SESSION['csrf_token']) ||
        !is_string($csrfToken) ||
        !hash_equals($_SESSION['csrf_token'], $csrfToken)
    ) {
        $errors[] = 'Your form session expired. Refresh the page and try again.';
    }

    if (!in_array($status, $allowedStatuses, true)) {
        $errors[] = 'Please select a valid complaint status.';
    }

    if (mb_strlen($response) > 5000) {
        $errors[] = 'The administrative response cannot exceed 5000 characters.';
    }

    if (!$errors) {
        try {
            $check = $pdo->prepare(
                'SELECT id FROM complaints WHERE id = :id LIMIT 1'
            );
            $check->execute(['id' => $complaintId]);

            if (!$check->fetch()) {
                $errors[] = 'This complaint could not be found.';
            } else {
                $update = $pdo->prepare(
                    'UPDATE complaints
                     SET status = :status,
                         admin_response = :admin_response,
                         updated_at = NOW()
                     WHERE id = :id'
                );

                $update->execute([
                    'status' => $status,
                    'admin_response' => $response !== '' ? $response : null,
                    'id' => $complaintId,
                ]);

                unset($_SESSION['csrf_token']);

                $_SESSION['admin_message'] =
                    'Complaint status and response updated successfully.';

                header('Location: complaints.php');
                exit;
            }
        } catch (PDOException $e) {
            error_log('CampusCare status update error: ' . $e->getMessage());
            $errors[] = 'The complaint could not be updated. Please try again later.';
        }
    }
}

try {
    $stmt = $pdo->prepare(
        'SELECT c.id, c.title, c.category, c.priority, c.location,
                c.description, c.status, c.admin_response, c.created_at,
                c.updated_at, u.name AS student_name, u.email AS student_email
         FROM complaints c
         INNER JOIN users u ON u.id = c.user_id
         WHERE c.id = :id
         LIMIT 1'
    );

    $stmt->execute(['id' => $complaintId]);
    $complaint = $stmt->fetch();

    if (!$complaint) {
        $_SESSION['admin_message'] = 'The requested complaint was not found.';
        header('Location: complaints.php');
        exit;
    }
} catch (PDOException $e) {
    error_log('CampusCare complaint review error: ' . $e->getMessage());
    http_response_code(500);
    exit('Unable to load this complaint right now.');
}

function updateStatusEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$csrfToken = $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32));

$currentStatus = $_POST['status'] ?? $complaint['status'];
$currentResponse = $_POST['admin_response'] ?? $complaint['admin_response'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Complaint | CampusCare</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="app-page">

<header class="navbar app-navbar">
    <a href="dashboard.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="dashboard.php">Overview</a>
        <a href="complaints.php" class="active">Manage Complaints</a>
        <a href="../logout.php" class="nav-login">Logout</a>
    </nav>
</header>

<main class="dashboard-container">
    <div class="page-heading">
        <a href="complaints.php" class="back-link">&larr; Back to Complaints</a>
        <span class="eyebrow">ADMINISTRATOR REVIEW</span>
        <h1>Review Complaint #<?= (int) $complaint['id'] ?></h1>
        <p>Review the student's report and record the latest decision.</p>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
            <strong>Please check the following:</strong>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= updateStatusEscape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <section class="form-panel">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">SUBMISSION DETAILS</span>
                <h2><?= updateStatusEscape($complaint['title']) ?></h2>
            </div>
            <span class="status-badge">
                <?= updateStatusEscape($complaint['status']) ?>
            </span>
        </div>

        <div class="complaint-details">
            <div class="detail-item">
                <span>Student</span>
                <strong><?= updateStatusEscape($complaint['student_name']) ?></strong>
            </div>

            <div class="detail-item">
                <span>Email</span>
                <strong><?= updateStatusEscape($complaint['student_email']) ?></strong>
            </div>

            <div class="detail-item">
                <span>Category</span>
                <strong><?= updateStatusEscape($complaint['category']) ?></strong>
            </div>

            <div class="detail-item">
                <span>Priority</span>
                <strong><?= updateStatusEscape($complaint['priority']) ?></strong>
            </div>

            <div class="detail-item">
                <span>Location</span>
                <strong><?= updateStatusEscape($complaint['location'] ?: 'Not provided') ?></strong>
            </div>

            <div class="detail-item">
                <span>Date Submitted</span>
                <strong>
                    <?= updateStatusEscape(date('d M Y, h:i A', strtotime($complaint['created_at']))) ?>
                </strong>
            </div>
        </div>

        <div class="description-box">
            <h3>Complaint Description</h3>
            <p><?= nl2br(updateStatusEscape($complaint['description'])) ?></p>
        </div>

        <form method="POST"
              action="update_status.php?id=<?= (int) $complaint['id'] ?>"
              class="portal-form"
              data-validate>

            <input type="hidden" name="id" value="<?= (int) $complaint['id'] ?>">
            <input type="hidden" name="csrf_token"
                   value="<?= updateStatusEscape($csrfToken) ?>">

            <div class="form-group">
                <label for="status">Update Complaint Status <span>*</span></label>
                <select id="status" name="status" required>
                    <?php foreach ($allowedStatuses as $status): ?>
                        <option value="<?= updateStatusEscape($status) ?>"
                            <?= $currentStatus === $status ? 'selected' : '' ?>>
                            <?= updateStatusEscape($status) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="admin_response">Administrative Response</label>
                <textarea
                    id="admin_response"
                    name="admin_response"
                    rows="5"
                    maxlength="5000"
                    placeholder="Enter an update or explain the action taken..."
                ><?= updateStatusEscape($currentResponse) ?></textarea>
                <small>This response will be available for the student to view.</small>
            </div>

            <div class="form-actions">
                <a href="complaints.php" class="btn btn-outline">Cancel</a>
                <button type="submit" class="btn">
                    Save Changes <span aria-hidden="true">&rarr;</span>
                </button>
            </div>
        </form>
    </section>
</main>

<footer class="footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare Administration</p>
</footer>

<script src="../js/validation.js"></script>
</body>
</html>
