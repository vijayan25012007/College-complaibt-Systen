<?php
$basePath = $basePath ?? '';
?>

<footer class="site-footer">
    <div class="footer-content">
        <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>index.php"
           class="footer-brand">
            CampusCare
        </a>

        <p>
            Making campus life better, one solution at a time.
        </p>

        <p class="footer-copy">
            &copy; <?= date('Y') ?> CampusCare.
            All rights reserved.
        </p>
    </div>
</footer>

<script src="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>js/validation.js"></script>
</body>
</html>