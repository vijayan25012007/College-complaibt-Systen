<?php
$pageTitle = $pageTitle ?? 'CampusCare';
$basePath = $basePath ?? '';

$isLoggedIn = isset($_SESSION['user_id']);
$userName = $_SESSION['user_name'] ?? 'User';
$userRole = $_SESSION['user_role'] ?? 'student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#10172a">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> | CampusCare</title>
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>css/style.css">
</head>
<body>

<header class="navbar app-navbar">
    <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>index.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links" aria-label="Main navigation">
        <?php if ($isLoggedIn && $userRole === 'admin'): ?>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>admin/dashboard.php">Dashboard</a>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>admin/complaints.php">Complaints</a>

        <?php elseif ($isLoggedIn): ?>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>dashboard.php">Dashboard</a>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>complaint.php">Report an Issue</a>
        <?php endif; ?>

        <?php if ($isLoggedIn): ?>
            <span class="nav-user">
                <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
            </span>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>logout.php" class="nav-login">
                Logout
            </a>
        <?php else: ?>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>login.php">Login</a>
            <a href="<?= htmlspecialchars($basePath, ENT_QUOTES, 'UTF-8') ?>register.php" class="nav-login">
                Register
            </a>
        <?php endif; ?>
    </nav>
</header>
