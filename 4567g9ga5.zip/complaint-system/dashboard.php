<?php
session_start();

require_once __DIR__ . '/config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'Student';
$userRole = $_SESSION['user_role'] ?? 'student';

if ($userRole === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

$stats = [
    'total' => 0,
    'pending' => 0,
    'in_progress' => 0,
    'resolved' => 0,
];

$recentComplaints = [];
$loadError = false;

try {
    $stmt = $pdo->prepare(
        'SELECT
            COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN status = "Pending" THEN 1 ELSE 0 END), 0) AS pending,
            COALESCE(SUM(CASE WHEN status = "In Progress" THEN 1 ELSE 0 END), 0) AS in_progress,
            COALESCE(SUM(CASE WHEN status = "Resolved" THEN 1 ELSE 0 END), 0) AS resolved
         FROM complaints
         WHERE user_id = :user_id'
    );

    $stmt->execute(['user_id' => $userId]);
    $stats = $stmt->fetch() ?: $stats;

    $stmt = $pdo->prepare(
        'SELECT id, title, category, status, created_at
         FROM complaints
         WHERE user_id = :user_id
         ORDER BY created_at DESC
         LIMIT 5'
    );

    $stmt->execute(['user_id' => $userId]);
    $recentComplaints = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('CampusCare dashboard error: ' . $e->getMessage());
    $loadError = true;
}

function dashboardStatusClass(string $status): string
{
    return match ($status) {
        'Resolved' => 'status-resolved',
        'In Progress' => 'status-progress',
        'Rejected' => 'status-rejected',
        default => 'status-pending',
    };
}

function dashboardEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | CampusCare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="app-page">

<header class="navbar app-navbar">
    <a href="dashboard.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="complaint.php">My Complaints</a>
        <a href="complaint.php" class="btn btn-small">+ New Complaint</a>
        <a href="logout.php" class="nav-login">Logout</a>
    </nav>
</header>

<main class="dashboard-container">
    <section class="welcome-banner">
        <div>
            <span class="eyebrow">STUDENT PORTAL</span>
            <h1>Welcome back, <?= dashboardEscape($userName) ?>!</h1>
            <p>Here's an overview of your campus complaints.</p>
        </div>

        <a href="complaint.php" class="btn">
            + Submit Complaint
        </a>
    </section>

    <?php if ($loadError): ?>
        <div class="alert alert-error" role="alert">
            Your dashboard information could not be loaded.
            Please try again later.
        </div>
    <?php endif; ?>

    <section class="stats-grid" aria-label="Complaint statistics">
        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">Total Complaints</span>
                <span class="stat-icon purple">&#9776;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['total'] ?></p>
            <span class="stat-caption">All your submissions</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">Pending</span>
                <span class="stat-icon orange">&#9711;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['pending'] ?></p>
            <span class="stat-caption">Awaiting review</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">In Progress</span>
                <span class="stat-icon teal">&#8635;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['in_progress'] ?></p>
            <span class="stat-caption">Being addressed</span>
        </article>

        <article class="stat-card">
            <div class="stat-top">
                <span class="stat-label">Resolved</span>
                <span class="stat-icon green">&#10003;</span>
            </div>
            <p class="stat-number"><?= (int) $stats['resolved'] ?></p>
            <span class="stat-caption">Successfully resolved</span>
        </article>
    </section>

    <section class="content-panel">
        <div class="panel-heading">
            <div>
                <span class="eyebrow">YOUR ACTIVITY</span>
                <h2>Recent Complaints</h2>
            </div>
            <a href="complaint.php" class="text-link">Submit a complaint &rarr;</a>
        </div>

        <?php if (!$recentComplaints): ?>
            <div class="empty-state">
                <div class="empty-icon">&#9998;</div>
                <h3>No complaints yet</h3>
                <p>
                    When you submit a complaint, its latest status
                    will appear here.
                </p>
                <a href="complaint.php" class="btn">Submit Your First Complaint</a>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                    <tr>
                        <th>Complaint</th>
                        <th>Category</th>
                        <th>Date Submitted</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentComplaints as $complaint): ?>
                        <tr>
                            <td>
                                <strong><?= dashboardEscape($complaint['title']) ?></strong>
                                <span class="table-subtext">
                                    Reference #<?= (int) $complaint['id'] ?>
                                </span>
                            </td>
                            <td><?= dashboardEscape($complaint['category']) ?></td>
                            <td>
                                <?= dashboardEscape(
                                    date('d M Y', strtotime($complaint['created_at']))
                                ) ?>
                            </td>
                            <td>
                                <span class="status-badge <?= dashboardStatusClass($complaint['status']) ?>">
                                    <?= dashboardEscape($complaint['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="help-panel">
        <div>
            <h3>Have a new campus concern?</h3>
            <p>Share the details so the administration can review it.</p>
        </div>
        <a href="complaint.php" class="btn btn-outline">Report an Issue &rarr;</a>
    </section>
</main>

<footer class="footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare</p>
</footer>

<script src="js/validation.js"></script>
</body>
</html>