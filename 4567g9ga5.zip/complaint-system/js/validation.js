"use strict";

document.addEventListener("DOMContentLoaded", () => {
    // Button click glow animation
    document.querySelectorAll(".btn, button").forEach((button) => {
        button.addEventListener("click", () => {
            button.classList.remove("click-glow");

            // Restart the animation when clicked repeatedly
            void button.offsetWidth;

            button.classList.add("click-glow");

            window.setTimeout(() => {
                button.classList.remove("click-glow");
            }, 500);
        });
    });

    // Client-side validation for forms
    document.querySelectorAll("form[data-validate]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            let firstInvalidField = null;

            form.querySelectorAll("[required]").forEach((field) => {
                field.setCustomValidity("");

                if (!field.value.trim()) {
                    field.setCustomValidity("Please complete this field.");
                } else if (
                    field.type === "email" &&
                    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())
                ) {
                    field.setCustomValidity("Please enter a valid email address.");
                }

                if (!field.checkValidity()) {
                    firstInvalidField ??= field;
                }
            });

            if (firstInvalidField) {
                event.preventDefault();
                firstInvalidField.reportValidity();
                firstInvalidField.focus();
            }
        });

        // Clear validation messages as users correct their input
        form.querySelectorAll("input, textarea, select").forEach((field) => {
            field.addEventListener("input", () => {
                field.setCustomValidity("");
            });

            field.addEventListener("change", () => {
                field.setCustomValidity("");
            });
        });
    });

    // Confirmation for actions that could change complaint data
    document.querySelectorAll("[data-confirm]").forEach((element) => {
        element.addEventListener("click", (event) => {
            const message =
                element.getAttribute("data-confirm") ||
                "Are you sure you want to continue?";

            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Automatically dismiss temporary messages
    document.querySelectorAll("[data-auto-dismiss]").forEach((message) => {
        window.setTimeout(() => {
            message.style.transition = "opacity 0.4s ease";
            message.style.opacity = "0";

            window.setTimeout(() => {
                message.remove();
            }, 400);
        }, 5000);
    });
});
