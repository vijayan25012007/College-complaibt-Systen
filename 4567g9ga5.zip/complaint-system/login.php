<?php
session_start();

require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if ($password === '') {
        $errors[] = 'Please enter your password.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                session_regenerate_id(true);

                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];

                header('Location: dashboard.php');
                exit;
            }

            $errors[] = 'Invalid email or password. Please try again.';
        } catch (PDOException $e) {
            error_log('CampusCare login error: ' . $e->getMessage());
            $errors[] = 'Login is temporarily unavailable. Please try again later.';
        }
    }
}

$success = $_SESSION['registration_success'] ?? '';
unset($_SESSION['registration_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | CampusCare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">

<header class="navbar">
    <a href="index.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="register.php" class="btn btn-small">Create Account</a>
    </nav>
</header>

<main class="auth-container">
    <section class="auth-card">
        <div class="auth-heading">
            <span class="eyebrow">WELCOME BACK</span>
            <h1>Sign in to CampusCare</h1>
            <p>Access your complaints and follow their progress.</p>
        </div>

        <?php if ($success !== ''): ?>
            <div class="alert alert-success" role="status">
                <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="alert alert-error" role="alert">
                <strong>Unable to sign in:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php" class="auth-form" data-validate>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="you@example.com"
                    value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                    autocomplete="email"
                    maxlength="190"
                    required
                    autofocus
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button type="submit" class="btn btn-full">
                Sign In <span aria-hidden="true">&rarr;</span>
            </button>

            <p class="auth-switch">
                Don't have an account?
                <a href="register.php">Register now</a>
            </p>
        </form>
    </section>
</main>

<footer class="footer auth-footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare</p>
</footer>

<script src="js/validation.js"></script>
</body>
</html>
