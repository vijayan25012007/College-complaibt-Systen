<?php
session_start();

require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$name = '';
$email = '';
$student_id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $student_id = trim($_POST['student_id'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($name === '' || mb_strlen($name) < 2) {
        $errors[] = 'Please enter your full name (at least 2 characters).';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if ($student_id === '' || mb_strlen($student_id) > 50) {
        $errors[] = 'Please enter a valid student ID.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Your password must contain at least 8 characters.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'The passwords do not match.';
    }

    if (!$errors) {
        try {
            $check = $pdo->prepare(
                'SELECT id FROM users WHERE email = :email OR student_id = :student_id LIMIT 1'
            );
            $check->execute([
                'email' => $email,
                'student_id' => $student_id,
            ]);

            if ($check->fetch()) {
                $errors[] = 'An account with this email or student ID already exists.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);

                $insert = $pdo->prepare(
                    'INSERT INTO users (name, email, student_id, password, role)
                     VALUES (:name, :email, :student_id, :password, :role)'
                );

                $insert->execute([
                    'name' => $name,
                    'email' => $email,
                    'student_id' => $student_id,
                    'password' => $hash,
                    'role' => 'student',
                ]);

                $_SESSION['registration_success'] =
                    'Your account has been created. You can now sign in.';

                header('Location: login.php');
                exit;
            }
        } catch (PDOException $e) {
            error_log('CampusCare registration error: ' . $e->getMessage());
            $errors[] = 'Registration could not be completed. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | CampusCare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">

<header class="navbar">
    <a href="index.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>
    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="login.php" class="nav-login">Sign In</a>
    </nav>
</header>

<main class="auth-container">
    <section class="auth-card">
        <div class="auth-heading">
            <span class="eyebrow">JOIN CAMPUSCARE</span>
            <h1>Create your account</h1>
            <p>Register to report campus concerns and track updates.</p>
        </div>

        <?php if ($errors): ?>
            <div class="alert alert-error" role="alert">
                <strong>Please check the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php" class="auth-form" data-validate>
            <div class="form-group">
                <label for="name">Full Name</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Enter your full name"
                    value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
                    autocomplete="name"
                    minlength="2"
                    maxlength="100"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email">College Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="you@example.com"
                    value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                    autocomplete="email"
                    maxlength="190"
                    required
                >
            </div>

            <div class="form-group">
                <label for="student_id">Student ID / Register Number</label>
                <input
                    type="text"
                    id="student_id"
                    name="student_id"
                    placeholder="Enter your student ID"
                    value="<?= htmlspecialchars($student_id, ENT_QUOTES, 'UTF-8') ?>"
                    maxlength="50"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="At least 8 characters"
                    autocomplete="new-password"
                    minlength="8"
                    required
                >
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Re-enter your password"
                    autocomplete="new-password"
                    minlength="8"
                    required
                >
            </div>

            <button type="submit" class="btn btn-full">
                Create Account <span aria-hidden="true">&rarr;</span>
            </button>

            <p class="auth-switch">
                Already have an account?
                <a href="login.php">Sign in</a>
            </p>
        </form>
    </section>
</main>

<footer class="footer auth-footer">
    <p class="copyright">&copy; <?= date('Y') ?> CampusCare</p>
</footer>

<script src="js/validation.js"></script>
</body>
</html>
