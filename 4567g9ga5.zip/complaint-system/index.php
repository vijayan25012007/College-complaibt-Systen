<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="CampusCare helps students report college complaints and track their resolution.">
    <title>CampusCare | College Complaint Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="navbar">
    <a href="index.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <nav class="nav-links">
        <a href="#features">Features</a>
        <a href="#how-it-works">How It Works</a>
        <a href="login.php" class="nav-login">Login</a>
        <a href="register.php" class="btn btn-small">Get Started</a>
    </nav>
</header>

<main>
    <section class="hero">
        <div class="hero-content">
            <span class="eyebrow">YOUR VOICE MATTERS</span>

            <h1>
                A better campus<br>
                starts with <span>your voice.</span>
            </h1>

            <p class="hero-description">
                Report college issues, follow complaint progress,
                and help create a better campus experience for everyone.
            </p>

            <div class="hero-actions">
                <a href="register.php" class="btn">
                    Create Account <span aria-hidden="true">&rarr;</span>
                </a>
                <a href="login.php" class="btn btn-outline">Sign In</a>
            </div>

            <div class="hero-note">
                <span class="status-dot"></span>
                One platform. Better campus experiences.
            </div>
        </div>

        <div class="hero-visual">
            <div class="visual-glow"></div>

            <div class="dashboard-preview">
                <div class="preview-header">
                    <div>
                        <span class="preview-label">CAMPUSCARE OVERVIEW</span>
                        <h3>Complaint Center</h3>
                    </div>
                    <span class="preview-icon">&#10003;</span>
                </div>

                <div class="preview-card">
                    <div class="preview-card-icon purple">&#9998;</div>
                    <div>
                        <strong>Submit a complaint</strong>
                        <p>Report campus issues easily</p>
                    </div>
                    <span class="preview-arrow">&rarr;</span>
                </div>

                <div class="preview-card">
                    <div class="preview-card-icon teal">&#8635;</div>
                    <div>
                        <strong>Track progress</strong>
                        <p>Follow your complaint status</p>
                    </div>
                    <span class="preview-arrow">&rarr;</span>
                </div>

                <div class="preview-card">
                    <div class="preview-card-icon orange">&#10003;</div>
                    <div>
                        <strong>View updates</strong>
                        <p>See responses from administrators</p>
                    </div>
                    <span class="preview-arrow">&rarr;</span>
                </div>

                <div class="preview-footer">
                    <span class="status-dot"></span>
                    Your concerns matter
                </div>
            </div>

            <div class="floating-tag tag-top">
                <span class="tag-check">&#10003;</span>
                Simple &amp; Transparent
            </div>

            <div class="floating-tag tag-bottom">
                <span class="tag-symbol">&#9672;</span>
                Better campus, together
            </div>
        </div>
    </section>

    <section class="features section" id="features">
        <div class="section-heading">
            <span class="eyebrow">BUILT FOR STUDENTS</span>
            <h2>Make your concerns count.</h2>
            <p>Tools to report issues and follow their progress in one place.</p>
        </div>

        <div class="feature-grid">
            <article class="feature-card">
                <div class="feature-icon purple">&#9998;</div>
                <h3>Easy Reporting</h3>
                <p>Report concerns about facilities, academics, maintenance, and campus services.</p>
            </article>

            <article class="feature-card">
                <div class="feature-icon teal">&#8635;</div>
                <h3>Track Complaints</h3>
                <p>Check the latest status of your submitted complaints.</p>
            </article>

            <article class="feature-card">
                <div class="feature-icon orange">&#10003;</div>
                <h3>Clear Updates</h3>
                <p>Review administrative responses and progress updates.</p>
            </article>
        </div>
    </section>

    <section class="how-section section" id="how-it-works">
        <div class="section-heading">
            <span class="eyebrow">THREE SIMPLE STEPS</span>
            <h2>From concern to resolution.</h2>
            <p>Getting your concern heard doesn't need to be complicated.</p>
        </div>

        <div class="steps-grid">
            <article class="step-card">
                <span class="step-number">01</span>
                <h3>Create an account</h3>
                <p>Register with your student details.</p>
            </article>

            <article class="step-card">
                <span class="step-number">02</span>
                <h3>Report an issue</h3>
                <p>Describe your concern and submit it.</p>
            </article>

            <article class="step-card">
                <span class="step-number">03</span>
                <h3>Follow the status</h3>
                <p>Sign in to check progress and updates.</p>
            </article>
        </div>

        <div class="cta-panel">
            <div>
                <span class="eyebrow">LET'S IMPROVE OUR CAMPUS</span>
                <h2>Ready to make a difference?</h2>
                <p>Create your account and make your voice heard.</p>
            </div>
            <a href="register.php" class="btn">
                Get Started <span aria-hidden="true">&rarr;</span>
            </a>
        </div>
    </section>
</main>

<footer class="footer">
    <a href="index.php" class="logo">
        <span class="logo-icon">C</span>
        CampusCare
    </a>

    <p>Building a better campus, together.</p>
    <p class="copyright">
        &copy; <?= date('Y') ?> CampusCare. All rights reserved.
    </p>
</footer>

<script src="js/validation.js"></script>
</body>
</html>